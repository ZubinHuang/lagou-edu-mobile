// 动态设置font-size(移动端兼容脚本)
let fontsize = document.documentElement.clientWidth / 3.75; //得到一个尺寸/比例=>html的fontsize 
    document.documentElement.style.fontSize = fontsize + 'px';

